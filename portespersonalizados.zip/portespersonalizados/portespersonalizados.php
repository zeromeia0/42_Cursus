<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class PortesPersonalizados extends Module
{
    public function __construct()
    {
        $this->name = 'portespersonalizados';
        $this->tab = 'shipping_logistics';
        $this->version = '1.0.0';
        $this->author = 'Vinicius Vaz';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Portes Personalizados');
        $this->description = $this->l('Calcula portes com base na região e peso, incluindo envio expresso.');
    }

    public function install()
    {
        return parent::install()
            && $this->installDatabase()
            && $this->registerHook('actionCarrierProcess');
    }

    public function uninstall()
    {
        return parent::uninstall()
            && $this->uninstallDatabase();
    }

    private function installDatabase()
    {
        $sql = "
        CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_ . "pp_shipping_prices` (
            `id_pp_shipping_prices` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `region` VARCHAR(64) NOT NULL,
            `weight_min` FLOAT NOT NULL,
            `weight_max` FLOAT NOT NULL,
            `price_normal` DECIMAL(10,2) NOT NULL,
            `price_express` DECIMAL(10,2) NOT NULL
        ) ENGINE="._MYSQL_ENGINE_ . " DEFAULT CHARSET=utf8mb4;";

        return Db::getInstance()->execute($sql);
    }

    private function uninstallDatabase()
    {
        $sql = "DROP TABLE IF EXISTS `"._DB_PREFIX_ . "pp_shipping_prices`";
        return Db::getInstance()->execute($sql);
    }

    public function getContent()
    {
        $output = '';

        if (Tools::isSubmit('submit_pp_upload')) {
            $output .= $this->processCsvUpload();
        }

        $output .= $this->displayForm();
        return $output;
    }

    private function displayForm()
    {
        return '
        <form method="post" enctype="multipart/form-data">
            <label>Importar tabela CSV:</label><br>
            <input type="file" name="pp_csv_file"><br><br>
            <input type="submit" name="submit_pp_upload" class="button" value="Importar">
        </form>
        ';
    }

    private function processCsvUpload()
    {
        if (!isset($_FILES['pp_csv_file']) || $_FILES['pp_csv_file']['error']) {
            return $this->displayError('Erro no upload do ficheiro CSV.');
        }

        $file = $_FILES['pp_csv_file']['tmp_name'];
        $handle = fopen($file, 'r');
        if (!$handle) {
            return $this->displayError('Não foi possível abrir o ficheiro.');
        }

        $header = fgetcsv($handle, 1000, ',');
        $expected = ['regiao','peso_min','peso_max','preco_normal','preco_express'];

        if ($header !== $expected) {
            return $this->displayError('Cabeçalho CSV inválido. Use: regiao,peso_min,peso_max,preco_normal,preco_express');
        }

        $db = Db::getInstance();
        $db->execute('TRUNCATE TABLE `'._DB_PREFIX_.'pp_shipping_prices`');

        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
            $db->insert('pp_shipping_prices', [
                'region' => pSQL($data[0]),
                'weight_min' => (float)$data[1],
                'weight_max' => (float)$data[2],
                'price_normal' => (float)$data[3],
                'price_express' => (float)$data[4],
            ]);
        }

        fclose($handle);
        return $this->displayConfirmation('Tabela de portes importada com sucesso!');
    }
}
