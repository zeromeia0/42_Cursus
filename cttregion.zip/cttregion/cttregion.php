<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class CttRegion extends Module
{
    public function __construct()
    {
        $this->name = 'cttregion';
        $this->version = '1.0.0';
        $this->author = 'Rodrigo';
        $this->need_instance = 0;

        parent::__construct();

        $this->displayName = 'CTT Região por Código Postal';
        $this->description = 'Mostra apenas a transportadora correta com base no código postal.';
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('header');
    }

    public function hookHeader()
    {
        if ($this->context->controller->php_self === 'checkout') {
            $this->context->controller->registerJavascript(
                'module-cttregion-js',
                'modules/' . $this->name . '/views/js/hide-shipping-options.js',
                ['position' => 'bottom', 'priority' => 150]
            );
        }
    }
}
