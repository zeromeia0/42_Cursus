document.addEventListener('DOMContentLoaded', function () {
    const zipInput = document.querySelector('input[name="address1"], input[name="postcode"]');
    
    if (!zipInput) return;

    function updateShippingOptions(zip) {
        zip = zip.replace(/\D/g, '');

        const shippingOptions = document.querySelectorAll('.delivery-option');

        shippingOptions.forEach(option => {
            const label = option.innerText.toLowerCase();

            if (zip.startsWith('9')) {
                if (label.includes('continental')) {
                    option.style.display = 'none';
                } else {
                    option.style.display = '';
                }
            } else if (zip.length >= 4) {
                if (label.includes('madeira') || label.includes('açores')) {
                    option.style.display = 'none';
                } else {
                    option.style.display = '';
                }
            }
        });
    }

    zipInput.addEventListener('input', function () {
        updateShippingOptions(this.value);
    });

    updateShippingOptions(zipInput.value);
});
